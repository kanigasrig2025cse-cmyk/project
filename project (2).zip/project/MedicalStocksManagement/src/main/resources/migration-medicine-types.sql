USE medicine_stock;
ALTER TABLE medicines ADD COLUMN medicine_type VARCHAR(30) NOT NULL DEFAULT 'Tablet';
