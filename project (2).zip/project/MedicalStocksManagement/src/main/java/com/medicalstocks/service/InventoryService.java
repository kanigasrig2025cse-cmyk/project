package com.medicalstocks.service;

import com.medicalstocks.db.Database;
import com.medicalstocks.model.Medicine;
import com.medicalstocks.model.Supplier;
import com.medicalstocks.model.Tablet;
import com.medicalstocks.model.Syrup;
import com.medicalstocks.model.Injection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class InventoryService {
    private static final String MEDICINE_SELECT = "SELECT medicine_id,medicine_type,name,category,manufacturer,batch_number,expiry_date,quantity,reorder_level,unit_price,supplier_id FROM medicines";

    public int addMedicine(String medicineType, String name, String category, String manufacturer, String batch, LocalDate expiry,
                           int quantity, int reorder, BigDecimal price, Integer supplierId) throws SQLException {
        String sql = "INSERT INTO medicines(medicine_type,name,category,manufacturer,batch_number,expiry_date,quantity,reorder_level,unit_price,supplier_id) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = Database.open(); PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1,medicineType);p.setString(2,name); p.setString(3,category); p.setString(4,manufacturer); p.setString(5,batch);
            p.setDate(6,Date.valueOf(expiry)); p.setInt(7,quantity); p.setInt(8,reorder); p.setBigDecimal(9,price);
            setNullableInt(p,10,supplierId); p.executeUpdate();
            try (ResultSet keys=p.getGeneratedKeys()) { keys.next(); return keys.getInt(1); }
        }
    }

    public List<Medicine> medicines(String search, String filter, int days) throws SQLException {
        StringBuilder sql = new StringBuilder(MEDICINE_SELECT + " WHERE 1=1");
        if (search != null && !search.isBlank()) sql.append(" AND (name LIKE ? OR batch_number LIKE ? OR manufacturer LIKE ?)");
        if ("expired".equals(filter)) sql.append(" AND expiry_date < CURDATE()");
        if ("expiring".equals(filter)) sql.append(" AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)");
        if ("low".equals(filter)) sql.append(" AND quantity <= reorder_level");
        sql.append(" ORDER BY expiry_date,name");
        try (Connection c=Database.open(); PreparedStatement p=c.prepareStatement(sql.toString())) {
            int i=1;
            if (search != null && !search.isBlank()) { String term="%"+search.trim()+"%"; p.setString(i++,term);p.setString(i++,term);p.setString(i++,term); }
            if ("expiring".equals(filter)) p.setInt(i,days);
            try (ResultSet r=p.executeQuery()) { List<Medicine> out=new ArrayList<>(); while(r.next()) out.add(mapMedicine(r)); return out; }
        }
    }

    public boolean updateMedicine(int id, String medicineType, String name, String category, String manufacturer, String batch,
                                  LocalDate expiry, int reorder, BigDecimal price, Integer supplierId) throws SQLException {
        String sql="UPDATE medicines SET medicine_type=?,name=?,category=?,manufacturer=?,batch_number=?,expiry_date=?,reorder_level=?,unit_price=?,supplier_id=? WHERE medicine_id=?";
        try(Connection c=Database.open();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,medicineType);p.setString(2,name);p.setString(3,category);p.setString(4,manufacturer);p.setString(5,batch);p.setDate(6,Date.valueOf(expiry));p.setInt(7,reorder);p.setBigDecimal(8,price);setNullableInt(p,9,supplierId);p.setInt(10,id);return p.executeUpdate()>0;
        }
    }
    public boolean deleteMedicine(int id) throws SQLException {
        try(Connection c=Database.open();PreparedStatement p=c.prepareStatement("DELETE FROM medicines WHERE medicine_id=?")){p.setInt(1,id);return p.executeUpdate()>0;}
    }

    public boolean deleteMedicineAndHistory(int id) throws SQLException {
        String[] statements = {
            "DELETE FROM purchases WHERE medicine_id=?",
            "DELETE FROM sales WHERE medicine_id=?",
            "DELETE FROM medicines WHERE medicine_id=?"
        };
        try (Connection c = Database.open()) {
            c.setAutoCommit(false);
            try {
                for (int i = 0; i < statements.length; i++) {
                    try (PreparedStatement p = c.prepareStatement(statements[i])) {
                        p.setInt(1, id);
                        int affected = p.executeUpdate();
                        if (i == statements.length - 1 && affected == 0) {
                            c.rollback();
                            return false;
                        }
                    }
                }
                c.commit();
                return true;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public int addSupplier(String name,String phone,String email,String address) throws SQLException {
        try(Connection c=Database.open();PreparedStatement p=c.prepareStatement("INSERT INTO suppliers(name,phone,email,address) VALUES(?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,name);p.setString(2,phone);p.setString(3,email);p.setString(4,address);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();return r.getInt(1);}
        }
    }
    public List<Supplier> suppliers() throws SQLException {
        try(Connection c=Database.open();PreparedStatement p=c.prepareStatement("SELECT supplier_id,name,phone,email,address FROM suppliers ORDER BY name");ResultSet r=p.executeQuery()){
            List<Supplier> out=new ArrayList<>();while(r.next())out.add(new Supplier(r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5)));return out;
        }
    }
    public boolean deleteSupplier(int id) throws SQLException {
        try(Connection c=Database.open();PreparedStatement p=c.prepareStatement("DELETE FROM suppliers WHERE supplier_id=?")){p.setInt(1,id);return p.executeUpdate()>0;}
    }

    public void recordPurchase(int medicineId,int supplierId,int quantity,BigDecimal cost) throws SQLException {
        String lock="SELECT quantity FROM medicines WHERE medicine_id=? FOR UPDATE";
        try(Connection c=Database.open()){c.setAutoCommit(false);try{
            try(PreparedStatement p=c.prepareStatement(lock)){p.setInt(1,medicineId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Medicine not found.");}}
            try(PreparedStatement p=c.prepareStatement("UPDATE medicines SET quantity=quantity+?, supplier_id=? WHERE medicine_id=?")){p.setInt(1,quantity);p.setInt(2,supplierId);p.setInt(3,medicineId);p.executeUpdate();}
            try(PreparedStatement p=c.prepareStatement("INSERT INTO purchases(medicine_id,supplier_id,quantity,unit_cost) VALUES(?,?,?,?)")){p.setInt(1,medicineId);p.setInt(2,supplierId);p.setInt(3,quantity);p.setBigDecimal(4,cost);p.executeUpdate();}
            c.commit();
        }catch(SQLException | RuntimeException e){c.rollback();throw e;}}
    }
    public void recordSale(int medicineId,int quantity,BigDecimal price) throws SQLException {
        try(Connection c=Database.open()){c.setAutoCommit(false);try{
            try(PreparedStatement p=c.prepareStatement("UPDATE medicines SET quantity=quantity-? WHERE medicine_id=? AND quantity>=?")){p.setInt(1,quantity);p.setInt(2,medicineId);p.setInt(3,quantity);if(p.executeUpdate()==0)throw new SQLException("Medicine not found or insufficient stock.");}
            try(PreparedStatement p=c.prepareStatement("INSERT INTO sales(medicine_id,quantity,unit_price) VALUES(?,?,?)")){p.setInt(1,medicineId);p.setInt(2,quantity);p.setBigDecimal(3,price);p.executeUpdate();}
            c.commit();
        }catch(SQLException | RuntimeException e){c.rollback();throw e;}}
    }

    public void printReports() throws SQLException {
        String sql="SELECT (SELECT COUNT(*) FROM medicines) medicines_count,(SELECT COALESCE(SUM(quantity),0) FROM medicines) units_in_stock,(SELECT COALESCE(SUM(quantity*unit_price),0) FROM medicines) inventory_value,(SELECT COALESCE(SUM(quantity*unit_price),0) FROM sales) sales_value,(SELECT COUNT(*) FROM medicines WHERE quantity<=reorder_level) low_stock";
        try(Connection c=Database.open();Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){r.next();System.out.printf("Medicines: %d | Units in stock: %d | Inventory value: %s | Recorded sales: %s | Low stock items: %d%n",r.getInt(1),r.getInt(2),r.getBigDecimal(3),r.getBigDecimal(4),r.getInt(5));}
    }
    public List<TransactionReport> transactionReports() throws SQLException {
        String sql = "SELECT * FROM ("
                + "SELECT 'Purchase' transaction_type, m.name medicine_name, p.quantity, p.unit_cost unit_price, p.quantity*p.unit_cost total, p.purchased_at transaction_time, s.name supplier_name "
                + "FROM purchases p JOIN medicines m ON m.medicine_id=p.medicine_id LEFT JOIN suppliers s ON s.supplier_id=p.supplier_id "
                + "UNION ALL "
                + "SELECT 'Sale', m.name, sa.quantity, sa.unit_price, sa.quantity*sa.unit_price, sa.sold_at, NULL "
                + "FROM sales sa JOIN medicines m ON m.medicine_id=sa.medicine_id) history ORDER BY transaction_time DESC";
        try (Connection c=Database.open(); PreparedStatement p=c.prepareStatement(sql); ResultSet r=p.executeQuery()) {
            List<TransactionReport> out=new ArrayList<>();
            while (r.next()) out.add(new TransactionReport(r.getString("transaction_type"),r.getString("medicine_name"),r.getInt("quantity"),r.getBigDecimal("unit_price"),r.getBigDecimal("total"),r.getTimestamp("transaction_time").toLocalDateTime(),r.getString("supplier_name")));
            return out;
        }
    }
    public DashboardStats dashboardStats() throws SQLException {
        String sql="SELECT (SELECT COUNT(*) FROM medicines) medicines_count,(SELECT COALESCE(SUM(quantity),0) FROM medicines) units_in_stock,(SELECT COALESCE(SUM(quantity*unit_price),0) FROM medicines) inventory_value,(SELECT COALESCE(SUM(quantity*unit_price),0) FROM sales) sales_value,(SELECT COUNT(*) FROM medicines WHERE quantity<=reorder_level) low_stock,(SELECT COUNT(*) FROM medicines WHERE expiry_date<CURDATE()) expired,(SELECT COUNT(*) FROM medicines WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)) expiring";
        try(Connection c=Database.open();Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){r.next();return new DashboardStats(r.getInt("medicines_count"),r.getInt("units_in_stock"),r.getBigDecimal("inventory_value"),r.getBigDecimal("sales_value"),r.getInt("low_stock"),r.getInt("expired"),r.getInt("expiring"));}
    }
    private static void setNullableInt(PreparedStatement p,int index,Integer value)throws SQLException{if(value==null)p.setNull(index,Types.INTEGER);else p.setInt(index,value);}
    private static Medicine mapMedicine(ResultSet r)throws SQLException{
        int sid=r.getInt("supplier_id");Integer supplier=r.wasNull()?null:sid;
        int id=r.getInt("medicine_id");String type=r.getString("medicine_type");String name=r.getString("name");
        String category=r.getString("category");String manufacturer=r.getString("manufacturer");String batch=r.getString("batch_number");
        LocalDate expiry=r.getDate("expiry_date").toLocalDate();int quantity=r.getInt("quantity");int reorder=r.getInt("reorder_level");BigDecimal price=r.getBigDecimal("unit_price");
        return switch(type){
            case "Syrup" -> new Syrup(id,name,category,manufacturer,batch,expiry,quantity,reorder,price,supplier);
            case "Injection" -> new Injection(id,name,category,manufacturer,batch,expiry,quantity,reorder,price,supplier);
            default -> new Tablet(id,name,category,manufacturer,batch,expiry,quantity,reorder,price,supplier);
        };
    }
    public record DashboardStats(int medicineCount,int unitsInStock,BigDecimal inventoryValue,BigDecimal salesValue,int lowStockCount,int expiredCount,int expiringCount){}
    public record TransactionReport(String type,String medicineName,int quantity,BigDecimal unitPrice,BigDecimal total,java.time.LocalDateTime time,String supplierName){}
}
