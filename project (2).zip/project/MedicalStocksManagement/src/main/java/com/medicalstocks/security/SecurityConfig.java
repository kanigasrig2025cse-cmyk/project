package com.medicalstocks.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/style.css").permitAll()
                .requestMatchers("/users/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/medicines/*/delete", "/suppliers/*/delete").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET, "/medicines/new", "/medicines/*/edit", "/suppliers", "/purchases/new", "/sales/new")
                    .hasAnyRole("ADMIN", "PHARMACIST")
                .requestMatchers(HttpMethod.POST, "/medicines", "/suppliers", "/purchases", "/sales")
                    .hasAnyRole("ADMIN", "PHARMACIST")
                .requestMatchers(HttpMethod.GET, "/", "/medicines", "/reports", "/alerts/**")
                    .hasAnyRole("ADMIN", "PHARMACIST", "DOCTOR")
                .anyRequest().authenticated())
            .formLogin(form -> form.loginPage("/login").permitAll().defaultSuccessUrl("/", true))
            .logout(logout -> logout.logoutSuccessUrl("/login?logout").permitAll())
            .exceptionHandling(errors -> errors.accessDeniedPage("/access-denied"));
        return http.build();
    }

    @Bean
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }
}
