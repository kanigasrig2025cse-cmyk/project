package com.medicalstocks.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public final class Tablet extends Medicine {
    public Tablet(int id, String name, String category, String manufacturer, String batchNumber,
                  LocalDate expiryDate, int quantity, int reorderLevel, BigDecimal unitPrice, Integer supplierId) {
        super(id, "Tablet", name, category, manufacturer, batchNumber, expiryDate, quantity, reorderLevel, unitPrice, supplierId);
    }
    @Override public String getTypeLabel() { return "Tablet"; }
}
