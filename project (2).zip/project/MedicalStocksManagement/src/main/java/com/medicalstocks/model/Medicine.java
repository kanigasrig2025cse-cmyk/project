package com.medicalstocks.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Medicine extends InventoryItem {
    private final String medicineType;
    private final String category;
    private final String manufacturer;
    private final Integer supplierId;

    public Medicine(int id, String medicineType, String name, String category, String manufacturer, String batchNumber,
                    LocalDate expiryDate, int quantity, int reorderLevel, BigDecimal unitPrice, Integer supplierId) {
        super(id, name, batchNumber, expiryDate, quantity, reorderLevel, unitPrice);
        this.medicineType = medicineType;
        this.category = category; this.manufacturer = manufacturer; this.supplierId = supplierId;
    }
    public String getCategory() { return category; }
    public String getManufacturer() { return manufacturer; }
    public Integer getSupplierId() { return supplierId; }
    public String getMedicineType() { return medicineType; }
    @Override public String getTypeLabel() { return medicineType; }
}
