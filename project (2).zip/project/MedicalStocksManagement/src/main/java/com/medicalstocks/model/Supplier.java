package com.medicalstocks.model;

public record Supplier(int id, String name, String phone, String email, String address) {}
