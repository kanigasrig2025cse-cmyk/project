package com.medicalstocks.service;

import com.medicalstocks.db.Database;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserAccountService {
    private static final List<String> ROLES = List.of("ADMIN", "PHARMACIST", "DOCTOR");
    private final PasswordEncoder passwordEncoder;

    public UserAccountService(PasswordEncoder passwordEncoder) { this.passwordEncoder = passwordEncoder; }

    public List<Account> allAccounts() throws SQLException {
        String sql = "SELECT user_id,username,role,active,created_at FROM app_users ORDER BY username";
        try (Connection c = Database.open(); PreparedStatement p = c.prepareStatement(sql); ResultSet r = p.executeQuery()) {
            List<Account> accounts = new ArrayList<>();
            while (r.next()) accounts.add(new Account(r.getInt("user_id"), r.getString("username"), r.getString("role"), r.getBoolean("active"), r.getTimestamp("created_at").toLocalDateTime().toLocalDate().toString()));
            return accounts;
        }
    }

    public void createAccount(String username, String password, String role) throws SQLException {
        String cleanName = username == null ? "" : username.trim();
        if (cleanName.length() < 3 || cleanName.length() > 80) throw new IllegalArgumentException("Username must be between 3 and 80 characters.");
        if (password == null || password.length() < 8) throw new IllegalArgumentException("Password must be at least 8 characters.");
        if (!ROLES.contains(role)) throw new IllegalArgumentException("Choose Admin, Pharmacist, or Doctor.");
        try (Connection c = Database.open(); PreparedStatement p = c.prepareStatement("INSERT INTO app_users(username,password_hash,role,active) VALUES(?,?,?,TRUE)")) {
            p.setString(1, cleanName); p.setString(2, passwordEncoder.encode(password)); p.setString(3, role); p.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) throw new IllegalArgumentException("That username already exists.");
            throw e;
        }
    }

    public void deleteAccount(int userId, String actingUsername) throws SQLException {
        try (Connection c = Database.open()) {
            c.setAutoCommit(false);
            try {
                String username;
                String role;
                try (PreparedStatement p = c.prepareStatement("SELECT username,role FROM app_users WHERE user_id=? FOR UPDATE")) {
                    p.setInt(1, userId);
                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) throw new IllegalArgumentException("Account not found.");
                        username = r.getString("username");
                        role = r.getString("role");
                    }
                }
                if (username.equalsIgnoreCase(actingUsername)) throw new IllegalArgumentException("You cannot delete the account you are currently signed in with.");
                if ("ADMIN".equals(role)) {
                    try (PreparedStatement p = c.prepareStatement("SELECT COUNT(*) FROM app_users WHERE role='ADMIN' AND active=TRUE"); ResultSet r = p.executeQuery()) {
                        r.next();
                        if (r.getInt(1) <= 1) throw new IllegalArgumentException("The last active Admin account cannot be deleted.");
                    }
                }
                try (PreparedStatement p = c.prepareStatement("DELETE FROM app_users WHERE user_id=?")) {
                    p.setInt(1, userId);
                    p.executeUpdate();
                }
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public record Account(int id, String username, String role, boolean active, String createdDate) {}
}
