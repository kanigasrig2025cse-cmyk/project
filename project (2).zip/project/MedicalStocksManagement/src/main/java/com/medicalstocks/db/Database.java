package com.medicalstocks.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Database {
    private Database() {}

    public static Connection open() throws SQLException {
        String url = setting("DB_URL", "jdbc:mysql://localhost:3306/medicine_stock?serverTimezone=UTC");
        String user = setting("DB_USER", "root");
        String password = setting("DB_PASSWORD", "");
        return DriverManager.getConnection(url, user, password);
    }

    private static String setting(String key, String fallback) {
        String value = System.getenv(key);
        return value == null ? fallback : value;
    }
}
