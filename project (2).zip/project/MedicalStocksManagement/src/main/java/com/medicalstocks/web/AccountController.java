package com.medicalstocks.web;

import com.medicalstocks.service.UserAccountService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;

import java.sql.SQLException;

@Controller
public class AccountController {
    private final UserAccountService accounts;

    public AccountController(UserAccountService accounts) { this.accounts = accounts; }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/access-denied")
    public String accessDenied() { return "access-denied"; }

    @GetMapping("/users")
    public String users(Model model) throws SQLException {
        model.addAttribute("accounts", accounts.allAccounts());
        model.addAttribute("page", "users");
        return "users";
    }

    @PostMapping("/users")
    public String createUser(@RequestParam(name="username") String username,
                             @RequestParam(name="password") String password,
                             @RequestParam(name="role") String role,
                             RedirectAttributes flash) throws SQLException {
        try {
            accounts.createAccount(username, password, role);
            flash.addFlashAttribute("success", "Account created for " + username.trim() + ".");
        } catch (IllegalArgumentException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/users";
    }

    @PostMapping("/users/{id}/delete")
    public String deleteUser(@PathVariable("id") int id, Authentication authentication, RedirectAttributes flash) throws SQLException {
        try {
            accounts.deleteAccount(id, authentication.getName());
            flash.addFlashAttribute("success", "Account deleted.");
        } catch (IllegalArgumentException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/users";
    }
}
