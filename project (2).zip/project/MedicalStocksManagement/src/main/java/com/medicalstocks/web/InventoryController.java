package com.medicalstocks.web;

import com.medicalstocks.model.Medicine;
import com.medicalstocks.model.Supplier;
import com.medicalstocks.service.InventoryService;
import com.medicalstocks.service.InventoryService.DashboardStats;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

@Controller
public class InventoryController {
    private final InventoryService service;

    public InventoryController(InventoryService service) { this.service = service; }

    @GetMapping("/")
    public String dashboard(Model model) throws SQLException {
        model.addAttribute("stats", service.dashboardStats());
        model.addAttribute("medicines", service.medicines(null, null, 0));
        model.addAttribute("page", "dashboard");
        return "dashboard";
    }

    @GetMapping("/medicines")
    public String medicines(@RequestParam(name="search", required=false) String search, Model model) throws SQLException {
        model.addAttribute("medicines", service.medicines(search, null, 0));
        model.addAttribute("search", search == null ? "" : search);
        model.addAttribute("page", "medicines");
        return "medicines";
    }

    @GetMapping("/medicines/new")
    public String newMedicine(Model model) throws SQLException {
        model.addAttribute("medicine", null); model.addAttribute("suppliers", service.suppliers());
        model.addAttribute("page", "medicines"); return "medicine-form";
    }

    @GetMapping("/medicines/{id}/edit")
    public String editMedicine(@PathVariable("id") int id, Model model) throws SQLException {
        Medicine medicine = findMedicine(id);
        if (medicine == null) return "redirect:/medicines";
        model.addAttribute("medicine", medicine); model.addAttribute("suppliers", service.suppliers());
        model.addAttribute("page", "medicines"); return "medicine-form";
    }

    @PostMapping("/medicines")
    public String saveMedicine(@RequestParam(name="id", required=false) Integer id,
            @RequestParam(name="medicineType") String medicineType, @RequestParam(name="name") String name,
            @RequestParam(name="category", required=false) String category, @RequestParam(name="manufacturer", required=false) String manufacturer,
            @RequestParam(name="batchNumber") String batchNumber, @RequestParam(name="expiryDate") LocalDate expiryDate,
            @RequestParam(name="quantity", defaultValue="0") int quantity, @RequestParam(name="reorderLevel", defaultValue="10") int reorderLevel,
            @RequestParam(name="unitPrice") BigDecimal unitPrice, @RequestParam(name="supplierId", required=false) Integer supplierId,
            RedirectAttributes flash) throws SQLException {
        Integer sid = supplierId == null || supplierId == 0 ? null : supplierId;
        if (id == null) {
            int newId = service.addMedicine(medicineType,name,category,manufacturer,batchNumber,expiryDate,quantity,reorderLevel,unitPrice,sid);
            flash.addFlashAttribute("success", "Medicine added (ID " + newId + ").");
        } else {
            service.updateMedicine(id,medicineType,name,category,manufacturer,batchNumber,expiryDate,reorderLevel,unitPrice,sid);
            flash.addFlashAttribute("success", "Medicine updated.");
        }
        return "redirect:/medicines";
    }

    @PostMapping("/medicines/{id}/delete")
    public String deleteMedicine(@PathVariable("id") int id, RedirectAttributes flash) throws SQLException {
        flash.addFlashAttribute("success", service.deleteMedicineAndHistory(id)
                ? "Medicine and all associated purchase and sale history were permanently deleted."
                : "Medicine not found.");
        return "redirect:/medicines";
    }

    @GetMapping("/suppliers")
    public String suppliers(Model model) throws SQLException { model.addAttribute("suppliers",service.suppliers());model.addAttribute("page","suppliers");return "suppliers"; }

    @PostMapping("/suppliers")
    public String addSupplier(@RequestParam(name="name") String name,@RequestParam(name="phone",required=false) String phone,
            @RequestParam(name="email",required=false) String email,@RequestParam(name="address",required=false) String address,RedirectAttributes flash)throws SQLException{
        int id=service.addSupplier(name,phone,email,address);flash.addFlashAttribute("success","Supplier added (ID "+id+").");return "redirect:/suppliers";
    }

    @PostMapping("/suppliers/{id}/delete")
    public String deleteSupplier(@PathVariable("id") int id,RedirectAttributes flash)throws SQLException{flash.addFlashAttribute("success",service.deleteSupplier(id)?"Supplier deleted.":"Supplier not found.");return "redirect:/suppliers";}

    @GetMapping("/purchases/new")
    public String purchaseForm(Model model)throws SQLException{formLists(model);model.addAttribute("transaction","purchase");model.addAttribute("page","transactions");return "transaction-form";}

    @PostMapping("/purchases")
    public String purchase(@RequestParam(name="medicineId") int medicineId,@RequestParam(name="supplierId") int supplierId,@RequestParam(name="quantity") int quantity,
                           @RequestParam(name="unitPrice") BigDecimal unitPrice,RedirectAttributes flash)throws SQLException{
        service.recordPurchase(medicineId,supplierId,quantity,unitPrice);flash.addFlashAttribute("success","Purchase recorded and stock updated.");return "redirect:/medicines";
    }

    @GetMapping("/sales/new")
    public String saleForm(Model model)throws SQLException{formLists(model);model.addAttribute("transaction","sale");model.addAttribute("page","transactions");return "transaction-form";}

    @PostMapping("/sales")
    public String sale(@RequestParam(name="medicineId") int medicineId,@RequestParam(name="quantity") int quantity,@RequestParam(name="unitPrice") BigDecimal unitPrice,
                       RedirectAttributes flash)throws SQLException{
        service.recordSale(medicineId,quantity,unitPrice);flash.addFlashAttribute("success","Sale recorded and stock updated.");return "redirect:/medicines";
    }

    @GetMapping("/alerts/{type}")
    public String alerts(@PathVariable("type") String type, Model model)throws SQLException{
        String filter=switch(type){case "expired"->"expired";case "expiring"->"expiring";case "low-stock"->"low";default->"";};
        String title=switch(type){case "expired"->"Expired medicines";case "expiring"->"Expiring in the next 30 days";case "low-stock"->"Low stock";default->"Inventory";};
        model.addAttribute("medicines",service.medicines(null,filter,30));model.addAttribute("pageTitle",title);model.addAttribute("search","");model.addAttribute("page","alerts");return "medicines";
    }

    @GetMapping("/reports")
    public String reports(Model model)throws SQLException{model.addAttribute("stats",service.dashboardStats());model.addAttribute("transactions",service.transactionReports());model.addAttribute("page","reports");return "reports";}

    @GetMapping(value="/reports/export", produces="text/csv")
    public ResponseEntity<String> exportReports() throws SQLException {
        StringBuilder csv = new StringBuilder("Type,Date and time,Medicine,Supplier,Quantity,Unit price,Total\r\n");
        for (var t : service.transactionReports()) {
            csv.append(csv(t.type())).append(',')
                    .append(csv(t.time().toString().replace('T', ' '))).append(',')
                    .append(csv(t.medicineName())).append(',')
                    .append(csv(t.supplierName() == null ? "" : t.supplierName())).append(',')
                    .append(t.quantity()).append(',').append(t.unitPrice()).append(',').append(t.total()).append("\r\n");
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=medstock-transactions.csv")
                .contentType(new MediaType("text", "csv", java.nio.charset.StandardCharsets.UTF_8))
                .body("\uFEFF" + csv);
    }

    private static String csv(String value) {
        if (value == null) return "\"\"";
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    @ExceptionHandler(SQLException.class)
    public String databaseError(SQLException error,Model model){model.addAttribute("message","Could not complete the request. Check that MySQL is running, schema.sql is installed, and the database credentials are correct.");model.addAttribute("details",error.getMessage());return "database-error";}

    private void formLists(Model model)throws SQLException{model.addAttribute("medicines",service.medicines(null,null,0));model.addAttribute("suppliers",service.suppliers());}
    private Medicine findMedicine(int id)throws SQLException{for(Medicine medicine:service.medicines(null,null,0))if(medicine.getId()==id)return medicine;return null;}
}
