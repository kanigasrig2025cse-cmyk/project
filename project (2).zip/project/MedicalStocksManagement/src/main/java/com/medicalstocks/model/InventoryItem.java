package com.medicalstocks.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public abstract class InventoryItem {
    private final int id;
    private final String name;
    private final String batchNumber;
    private final LocalDate expiryDate;
    private final int quantity;
    private final int reorderLevel;
    private final BigDecimal unitPrice;

    protected InventoryItem(int id, String name, String batchNumber, LocalDate expiryDate,
                            int quantity, int reorderLevel, BigDecimal unitPrice) {
        this.id = id; this.name = name; this.batchNumber = batchNumber; this.expiryDate = expiryDate;
        this.quantity = quantity; this.reorderLevel = reorderLevel; this.unitPrice = unitPrice;
    }
    public int getId() { return id; }
    public String getName() { return name; }
    public String getBatchNumber() { return batchNumber; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public int getQuantity() { return quantity; }
    public int getReorderLevel() { return reorderLevel; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public abstract String getTypeLabel();
}
