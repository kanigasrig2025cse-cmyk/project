package com.medicalstocks.security;

import com.medicalstocks.db.Database;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class BootstrapAdmin implements ApplicationRunner {
    private final PasswordEncoder passwordEncoder;

    public BootstrapAdmin(PasswordEncoder passwordEncoder) { this.passwordEncoder = passwordEncoder; }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        String username = System.getenv("ADMIN_USERNAME");
        String password = System.getenv("ADMIN_PASSWORD");
        try (Connection connection = Database.open()) {
            try (PreparedStatement count = connection.prepareStatement("SELECT COUNT(*) FROM app_users");
                 ResultSet result = count.executeQuery()) {
                result.next();
                if (result.getInt(1) > 0) return;
            }
            if (username == null || username.isBlank() || password == null || password.length() < 8) {
                throw new IllegalStateException("No MedStock accounts exist. Set ADMIN_USERNAME and ADMIN_PASSWORD (at least 8 characters) in this terminal for the first run.");
            }
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO app_users(username,password_hash,role,active) VALUES(?,?,'ADMIN',TRUE)")) {
                insert.setString(1, username.trim());
                insert.setString(2, passwordEncoder.encode(password));
                insert.executeUpdate();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Could not initialize the account table. Run migration-user-accounts.sql and verify the MySQL connection.", e);
        }
    }
}
