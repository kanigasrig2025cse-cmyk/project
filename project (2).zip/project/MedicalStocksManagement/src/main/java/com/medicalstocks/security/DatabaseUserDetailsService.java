package com.medicalstocks.security;

import com.medicalstocks.db.Database;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Service
public class DatabaseUserDetailsService implements UserDetailsService {
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String sql = "SELECT username,password_hash,role,active FROM app_users WHERE username=?";
        try (Connection connection = Database.open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new UsernameNotFoundException("Invalid username or password.");
                return User.withUsername(result.getString("username"))
                        .password(result.getString("password_hash"))
                        .roles(result.getString("role"))
                        .disabled(!result.getBoolean("active"))
                        .build();
            }
        } catch (SQLException e) {
            throw new UsernameNotFoundException("Could not check the account. Verify the database connection.", e);
        }
    }
}
