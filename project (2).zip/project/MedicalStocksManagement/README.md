# Medicine Stock Management System

A browser based inventory application built with Java 17, Spring Boot, Thymeleaf, Maven, MySQL, and JDBC. Spring Boot starts a local web server; the pages are served at `http://localhost:8080`.

## Requirements

- JDK 17 or newer
- Maven 3.6.3 or newer
- MySQL 8 or newer

## Set up MySQL

Run `src/main/resources/schema.sql` in MySQL Workbench, or from PowerShell in this folder:

```powershell
Get-Content .\src\main\resources\schema.sql | mysql -u root -p
```

The script creates the `medicine_stock` database and the supplier, medicine, purchase, and sale tables.

If you already created the database using the earlier schema, run `src/main/resources/migration-medicine-types.sql` once to add the medicine type column before starting the updated app:

```powershell
Get-Content .\src\main\resources\migration-medicine-types.sql | mysql -u root -p
```

Run `src/main/resources/migration-user-accounts.sql` once to add role-based accounts to an existing database. It is safe to run again; it creates the table only if it does not already exist.

## Configure and start

The defaults are `jdbc:mysql://localhost:3306/medicine_stock?serverTimezone=UTC`, user `root`, and an empty password. In the VS Code integrated terminal, set your actual MySQL credentials if needed, then start the web server:

```powershell
$env:DB_URL = "jdbc:mysql://localhost:3306/medicine_stock?serverTimezone=UTC"
$env:DB_USER = "root"
$env:DB_PASSWORD = "your-mysql-password"
$env:ADMIN_USERNAME = "admin"
$env:ADMIN_PASSWORD = "choose-a-strong-password"
mvn clean spring-boot:run
```

On the first start with an empty account table, MedStock creates the initial Admin account from `ADMIN_USERNAME` and `ADMIN_PASSWORD`. Use a password with at least 8 characters. The password is stored as a BCrypt hash, not as plain text. After the first Admin account exists, the bootstrap variables are no longer needed. Sign in at `http://localhost:8080`; the Admin can create Pharmacist, Doctor, or additional Admin accounts from the **Users** page.

Keep the terminal open while using the application; press `Ctrl+C` there to stop the server. Database environment variables must be set in each new terminal session. Never commit passwords to the project.

## Pages

- Overview dashboard with inventory, stock, expiry, and low stock summaries
- Medicine list, search, add, update, and delete
- Supplier directory with add and delete
- Purchase recording that increases stock
- Sale recording that checks and decreases stock
- Permanent medicine deletion that first removes its purchase and sale history, with a confirmation prompt
- Login and role based access for Admin, Pharmacist, and Doctor
- Admin-only account management; Admin and Pharmacist can manage inventory and record stock movements; Doctor has read-only inventory, alerts, and reports access
- Admins can remove user accounts; the signed-in Admin and the last Admin account are protected from deletion
- Expired, expiring within 30 days, and low stock lists
- Inventory and recorded sales summary report

## Design

`InventoryItem` is an abstract base class, `Medicine` extends it, and `Tablet`, `Syrup`, and `Injection` extend `Medicine`. The service creates the matching subtype from the stored medicine type, and each subtype provides its own type label through polymorphism. Model data is encapsulated in private fields. Spring MVC controllers handle browser requests, the service layer applies inventory operations, and JDBC sends prepared statements to MySQL. Thymeleaf renders the HTML pages.

This is a local development application; it does not include production deployment configuration.

Deleting a medicine permanently removes its linked purchase and sale records as part of the same database transaction. The action is irreversible; the browser asks for confirmation before it is submitted.
